/* Christine Tobias
 * CIT-63-18779-2026SP
 * Module 3: mystuff[file creation 02/21/26]
 */
package mystuff;

public class MyStuff {

  String carMake;
  String carModel;
  int year;
  String carColor;
  int age;
  boolean goodCondition;
}
