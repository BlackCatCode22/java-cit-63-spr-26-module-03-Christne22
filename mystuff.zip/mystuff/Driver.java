/* Christine Tobias
 * CIT-63-18779-2026SP
 * Module 3: mystuff [file creation 02/21/26]
 */
package mystuff;

public class Driver {

  public static void main(String[] args) {
    MyStuff myCar = new MyStuff();
    myCar.carMake = "Toyota";
    myCar.carModel = "Prius";
    myCar.year = 2013;
    myCar.carColor = "white";
    myCar.age = 13;
    myCar.goodCondition = true;

    MyStuff myCar2 = new MyStuff();
    myCar2.carMake = "Toyota";
    myCar2.carModel = "Prius";
    myCar2.year = 2013;
    myCar2.carColor = "white";
    myCar2.age = 13;
    myCar2.goodCondition = true;

    System.out.println(myCar.carMake);

    System.out.println(myCar2.year);
  }
}
