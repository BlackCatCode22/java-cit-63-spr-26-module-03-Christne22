/* Christine Tobias
 * CIT-63-18779-2026SP
 * Module 3: myanimals [file creation 02/21/26]
 */
package myanimals;

public class Cat {

  public static final int MAX_LIVES = 9;

  private static int catCount = 0;
  String name;
  int age;

  @SuppressWarnings("unused")
  int livesRemaining;

  public void meow() {
    System.out.println("Meow");
  }

  public Cat() {
    catCount++;
    livesRemaining = MAX_LIVES;
  }

  public static int getCatCount() {
    return catCount;
  }
}
