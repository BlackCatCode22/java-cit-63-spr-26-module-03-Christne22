/* Christine Tobias
 * CIT-63-18779-2026SP
 * Module 3: myanimals [file creation 02/21/26]
 */
package myanimals;

public class Animal {

  public static void main(String[] args) {
    // System.out.println(Cat.getCatCount());

    // Cat object
    Cat myCat = new Cat();
    myCat.meow();
    myCat.name = "Stella";
    myCat.age = 8;

    System.out.println(Cat.MAX_LIVES);
    // System.out.println(Cat.getCatCount());

    // Dog object
    Dog myDog = new Dog();
    myDog.woof();
    myDog.name = "Bella";
    myDog.age = 5;
    // System.out.println(Dog.getDogCount());

    int numOfAnimals;
    numOfAnimals = Cat.getCatCount() + Dog.getDogCount();
    //Call getCatCount()
    System.out.println("Number of cats is: " + Cat.getCatCount());

    //Call getDogCount()
    System.out.println("Number of dogs is: " + Dog.getDogCount());

    System.out.println("Total number of Animals is: " + numOfAnimals);
  }
}
