/* Christine Tobias
 * CIT-63-18779-2026SP
 * Module 3: myanimals [file creation 02/21/26]
 */
package myanimals;

public class Dog {

  private static int dogCount = 0;
  String name;
  int age;

  public void woof() {
    System.out.println("Woof");
  }

  public Dog() {
    dogCount++;
  }

  public static int getDogCount() {
    return dogCount;
  }
}
