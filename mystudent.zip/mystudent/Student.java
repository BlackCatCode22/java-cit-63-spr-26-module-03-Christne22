/* Christine Tobias
 * CIT-63-18779-2026SP
 * Module 3: mystudent [file creation 02/21/26]
 */
package mystudent;

public class Student {

  String firstName;
  String lastName;
  double gpa;
  String major;
  int age;
  boolean onProbation;
}
