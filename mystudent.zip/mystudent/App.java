/* Christine Tobias
 * CIT-63-18779-2026SP
 * Module 3: mystudent [file creation 02/21/26]
 */
package mystudent;

public class App {

  public static void main(String[] args) {
    Student myStudent = new Student();
    myStudent.firstName = "Jim";
    myStudent.lastName = "Halpert";
    myStudent.gpa = 2.5;
    myStudent.major = "Business";
    myStudent.age = 24;
    myStudent.onProbation = false;

    Student myStudent2 = new Student();
    myStudent2.firstName = "Pam";
    myStudent2.lastName = "Beasley";
    myStudent2.gpa = 2.6;
    myStudent2.major = "Art";
    myStudent2.age = 23;
    myStudent2.onProbation = true;

    System.out.println(myStudent.firstName);
    System.out.println(myStudent2.firstName);
  }
}
